import React, { useRef, useState } from 'react'
import GraphLemin from './components/GraphLemin'
import Header from './components/Header'
import CardStep from './components/CardStep'
import { Paper, Grid, TextField, Button } from '@material-ui/core'
import ReplayIcon from '@material-ui/icons/Replay'
import PlayArrowIcon from '@material-ui/icons/PlayArrow'
import IconButton from '@material-ui/core/IconButton'
import { makeStyles, useTheme } from '@material-ui/core/styles'
import SkipNextIcon from '@material-ui/icons/SkipNext'

// import data from '../data.json'

const useStyles = makeStyles(theme => ({
  root: {
    display: 'flex'
  },
  details: {
    display: 'flex',
    flexDirection: 'column'
  },
  content: {
    flex: '1 0 auto'
  },
  cover: {
    width: 151
  },
  controls: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
    // paddingLeft: theme.spacing(1),
    // paddingBottom: theme.spacing(1)
  },
  playIcon: {
    height: 38,
    width: 38
  }
}))

const clsError = {
  validateRoom: 'Error validate by position room (block - rooms)',
  validateLinks: 'Name room not found in rooms object (block - links)',
  validateWays: 'Name room not found in rooms object (block - ways)',
  validateAnts: 'Name ants in way is not validate (block - ways',
  validateCount: 'Not Validate count Ants',
  main: 'Not parse'
}
const App = () => {
  const classes = useStyles()
  const theme = useTheme()
  const ob = useRef(null)
  const [dataMeta, setDataMeta] = useState(
    '10\n\
##end\n\
0 9 5\n\
7 4 8\n\
6 1 5\n\
5 9 3\n\
4 16 5\n\
3 16 6\n\
2 16 7\n\
##start\n\
1 23 3\n\
1-3\n\
1-2\n\
7-6\n\
7-4\n\
7-2\n\
6-5\n\
6-0\n\
5-3\n\
5-2\n\
4-3\n\
4-2\n\
4-0\n\
\n\
L2-2 L1-3\n\
L2-7 L4-2 L1-4 L3-3 \n\
L2-6 L4-7 L6-2 L1-0 L3-4 L5-3 \n\
L2-0 L4-6 L6-7 L8-2 L3-0 L5-4 L7-3 \n\
L4-0 L6-6 L8-7 L10-2 L5-0 L7-4 L9-3 \n\
L6-0 L8-6 L10-7 L7-0 L9-4 \n\
L8-0 L10-6 L9-0'
  )
  const [step, setStep] = useState(-1)

  const [state, setState] = useState({})
  const [links, setLinks] = useState([])
  const [ants, setAnts] = useState([])
  const [countAnts, setCountAnts] = useState(0)
  const [scale, setScale] = useState(20)
  const [te, setTe] = useState(0)
  const alert = str => {}

  const parse = () => {
    const [roomsT, linksT, waysT, countAntsT, error] = goParse()
    if (error) {
      alert(error)
      setState({})
      setLinks([])
      setAnts([])
      setCountAnts(0)
    } else {
      setState(roomsT)
      setLinks(linksT)
      setAnts(waysT)
      setCountAnts(countAntsT)
    }
    setTe(te + 1)
    setStep(-1)
  }

  const goParse = () => {
    const parseRooms = line => {
      const parseRoom = () => {
        const [name, x, y] = line.split(' ')
        if (!name || !x || !y) return { error: clsError.main }
        else if (isNaN(Number(x)) || isNaN(Number(y)))
          return { error: clsError.validateRoom }
        else
          return {
            name: name,
            x: Number(x) * scale,
            y: Number(y) * scale,
            type: ex
          }
      }

      if (line === '##start') ex = -1
      else if (line === '##end') ex = 1
      else if (line[0] != '#') {
        let roomTemp = parseRoom(line, ex)
        if (roomTemp['error']) {
          isRef = 1
          return roomTemp.error
        } else rooms[roomTemp.name] = roomTemp
        // console.log(ex, line, roomTemp)

        ex = 0
      }

      index += 1
      isRef = 0
      return clsError.main
    }

    const parseLinks = line => {
      const [room1, room2] = line.split('-')
      if (room1 && room2) {
        if (rooms[room1] && rooms[room2]) {
          links.push([room1, room2])
          index += 1
          return clsError.main
        } else {
          isRef = 2
          return clsError.validateLinks
        }
      }
      isRef = 2
      return clsError.main
    }

    const parseWays = line => {
      const oneStep = line.split(' ')
      const step = []
      let i = -1
      while (++i < oneStep.length) {
        if (oneStep[i] !== '') {
          let [nameAnt, nameRoom] = oneStep[i].split('-')
          if (
            isNaN(Number(nameAnt.substr(1))) ||
            Number(nameAnt.substr(1)) > count_ants ||
            Number(nameAnt.substr(1)) < 0
          )
            return clsError.validateAnts
          // console.log(nameRoom, rooms[nameRoom], oneStep)
          if (!(nameRoom && rooms[nameRoom])) return clsError.validateWays
          step.push(oneStep[i])
        }
      }
      if (step.length) ways.push(step)
      index += 1
      return clsError.main
    }

    const parseCount = line => {
      if (isNaN(Number(line))) {
        return clsError.validateCount
      }
      count_ants = Number(line)
      isRef = 0
      index += 1
      return clsError.main
    }

    let rowData = dataMeta.split('\n')
    if (isNaN(Number(rowData[0])))
      return [null, null, null, null, clsError.main]
    let count_ants = 0
    let rooms = {}
    let links = []
    let ways = []
    let index = 0
    let isRef = -1
    let ex = -1
    let isRooms = 0
    let error = clsError.main
    while (index < rowData.length) {
      if (isRef === -1) error = parseCount(rowData[index])
      if (error !== clsError.main) return [null, null, null, null, error]
      if (isRef === 0) error = parseRooms(rowData[index])
      if (error !== clsError.main) return [null, null, null, null, error]
      if (isRef === 1) error = parseLinks(rowData[index])
      if (error !== clsError.main) return [null, null, null, null, error]
      if (isRef === 2) error = parseWays(rowData[index])
      if (error !== clsError.main) return [null, null, null, null, error]
    }
    return [rooms, links, ways, count_ants, null]
  }

  return (
    <div className='App' style={{display: 'grid', gridTemplateRows: '70px'}}>
      <Header />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 4fr' }}>
        <div style={{ margin: 8, display: 'flex'}}>
          <Paper
            elevation={2}
            style={{ display: 'flex', flexGrow: 1, flexDirection: 'column' }}
          >
            <div
              style={{
                display: 'flex',
                flexGrow: 1,
                flexDirection: 'column',
                overflow: 'scroll'
              }}
            >
              <div
                style={{
                  display: 'flex',
                  padding: 8,
                  flexDirection: 'column'
                }}
              >
                <TextField
                  style={{ flexGrow: 1 }}
                  value={dataMeta}
                  onChange={e => setDataMeta(e.target.value)}
                  label='Meta Lemin'
                  multiline
                  variant='outlined'
                />
                <TextField
                  style={{ marginTop: 8 }}
                  id='standard-number'
                  label='Coordinate multiplier'
                  type='number'
                  variant='outlined'
                  value={scale}
                  onChange={e => setScale(e.target.value)}
                  InputLabelProps={{
                    shrink: true
                  }}
                />
                <Button
                  style={{ marginTop: 8 }}
                  variant='outlined'
                  color='primary'
                  onClick={e => parse()}
                >
                  {'Parse'}
                </Button>
              </div>
            </div>
            <Paper elevation={1} variant='outlined' style={{ margin: 8 }}>
              <div className={classes.controls}>
                <IconButton
                  aria-label='previous'
                  onClick={e => {
                    setStep(-1)
                  }}
                >
                  <ReplayIcon className={classes.playIcon}  />
                </IconButton>
                <IconButton
                  onClick={e => {
                    step <= 10 ? setStep(step + 1) : setStep(10 - 1)
                  }}
                >
                  <SkipNextIcon className={classes.playIcon} />
                </IconButton>
              </div>
            </Paper>

            {/* <CardStep/> */}
            {/* <button
              onClick={e => {
                step <= 10
                  ? setStep(step + 1)
                  : setStep(10 - 1)
              }}
            >
              {'Дальше'}
            </button>
            <button
              onClick={e => {
                setStep(-1)
              }}
            >
              {'Сначала'}
            </button> */}
          </Paper>
        </div>
        <div style={{ margin: 8, display: 'flex', flexGrow: 1 }}>
          <Paper style={{ display: 'flex', flexGrow: 1 }} ref={ob}>
            <GraphLemin
              key={te}
              width={ob}
              step={step}
              setStep={setStep}
              state={state}
              setState={setState}
              links={links}
              setLinks={setLinks}
              ants={ants}
              setAnts={setAnts}
              countAnts={countAnts}
            />
          </Paper>
        </div>
      </div>
    </div>
  )
}

export default App

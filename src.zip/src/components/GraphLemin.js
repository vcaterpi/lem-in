import React, { useEffect, useRef, useState } from 'react'
import ReactDOM from 'react-dom'
import { Stage, Layer, Circle, Text, Line, Group, Animation } from 'react-konva'
import Konva from 'konva'
import { blue, red, green, grey, brown } from '@material-ui/core/colors'

const GraphLemin = ({
  step,
  setStep,
  state,
  setState,
  links,
  setLinks,
  ants,
  setAnts,
  countAnts,
  ...props
}) => {
  const typeColor = {
    // '-1': ['#f44336', '#e57373'],
    // '0': ['#2196f3', '#64b5f6'],
    // '1': ['#4caf50', '#81c784']
    '-1': [red[500], red[100]],
    '0': [blue[500], blue[100]],
    '1': [green[500], green[100]]
  }

  // useEffect(() => {
  //   let temp = state
  //   Object.keys(state).map(obj => {
  //     temp[obj].x *= scale
  //     temp[obj].y *= scale
  //   })
  // }, [])

  const [metaAnts, setMetaAnts] = React.useState({})
  const layRef = useRef()
  const [te, setTe] = React.useState(0)

  // useEffect(() => {
  //   if (step == -1) {
  //     let metaAntsTemp = {}
  //     let refs = {}
  //     setMetaAnts({})
  //     const startNode = Object.keys(state).filter(
  //       obj => state[obj].type === -1
  //     )[0]
  //     let i = 0
  //     while (++i <= countAnts) {
  //       metaAntsTemp['L' + i] = { ...state[startNode], cur: startNode }
  //       const antMeta = layRef.current.children.filter(
  //         obj => obj.name() == 'L' + i + '_circle'
  //       )
  //       const antTextMeta = layRef.current.children.filter(
  //         obj => obj.name() == 'L' + i + '_text'
  //       )
  //       if (antMeta.length) antMeta[0].destroy()
  //       if (antTextMeta.length) antTextMeta[0].destroy()
  //     }
  //     console.log(metaAntsTemp)
  //     setTe(te + 1)
  //     setMetaAnts(metaAntsTemp)
  //   } else if (step < ants.length && step > -1) {
  //     const childrenLay = layRef.current.children
  //     ants[step].map(way => {
  //       const [nameAnt, nameNode] = way.split('-')
  //       const antMeta = childrenLay.filter(
  //         obj => obj.name() == nameAnt + '_circle'
  //       )[0]
  //       console.log(antMeta, childrenLay, nameAnt)
  //       antMeta.to({
  //         // zIndex: 1,
  //         x: state[nameNode].x,
  //         y: state[nameNode].y,
  //         duration: 0.5
  //       })
  //       const antTextMeta = childrenLay.filter(
  //         obj => obj.name() == nameAnt + '_text'
  //       )[0]
  //       antTextMeta.to({
  //         // zIndex: 1,
  //         x: state[nameNode].x - 5,
  //         y: state[nameNode].y - 5,
  //         duration: 0.5
  //       })
  //     })
  //   }
  // }, [])

  useEffect(() => {
    if (step == -1) {
      let metaAntsTemp = {}
      let refs = {}
      setMetaAnts({})
      const startNode = Object.keys(state).filter(
        obj => state[obj].type === -1
      )[0]
      let i = 0
      while (++i <= countAnts) {
        metaAntsTemp['L' + i] = { ...state[startNode], cur: startNode }
        const antMeta = layRef.current.children.filter(
          obj => obj.name() == 'L' + i + '_circle'
        )
        const antTextMeta = layRef.current.children.filter(
          obj => obj.name() == 'L' + i + '_text'
        )
        if (antMeta.length) antMeta[0].destroy()
        if (antTextMeta.length) antTextMeta[0].destroy()
      }
      setTe(te + 1)
      setMetaAnts(metaAntsTemp)
    } else if (step < ants.length && step > -1) {
      const childrenLay = layRef.current.children
      ants[step].map(way => {
        const [nameAnt, nameNode] = way.split('-')
        const antMeta = childrenLay.filter(
          obj => obj.name() == nameAnt + '_circle'
        )[0]
        antMeta.to({
          // zIndex: 1,
          x: state[nameNode].x,
          y: state[nameNode].y,
          duration: 0.5
        })
        const antTextMeta = childrenLay.filter(
          obj => obj.name() == nameAnt + '_text'
        )[0]
        antTextMeta.to({
          // zIndex: 1,
          x: state[nameNode].x - 5,
          y: state[nameNode].y - 5,
          duration: 0.5
        })
      })
    }
    // setTimeout(() => {
    //   setStep(step + 1)
    // }, 500)
    // else {
    //   setStep()
    // }
  }, [step])

  const updateMetaAnts = () => {
    if (Object.keys(metaAnts).length) {
      let metaAntsTemp = {}
      Object.keys(metaAnts).map(nameAnt => {
        metaAntsTemp[nameAnt] = {
          ...metaAnts[nameAnt],
          ...state[metaAnts[nameAnt].cur]
        }
      })
      setMetaAnts(metaAntsTemp)
    }
  }

  useEffect(() => {
    if (Object.keys(metaAnts).length > -1) {
      updateMetaAnts()
      setStep(-1)
    }
  }, [state])

  const handleDrag = e => {
    setState({
      ...state,
      [e.target.name()]: {
        ...e.target.position(),
        type: state[e.target.name()].type
      }
    })
  }

  const getLinks = () => {
    return links.map(link => {
      return (
        <Line
          points={[
            state[link[0]].x,
            state[link[0]].y,
            state[link[1]].x,
            state[link[1]].y
          ]}
          stroke={grey[500]}
        />
      )
    })
  }

  const getTextNode = () => {
    return Object.keys(state).map(nameState => {
      return (
        <Text
          {...state[nameState]}
          x={state[nameState].x - 6}
          y={state[nameState].y - 46}
          text={nameState}
          fill={'black'}
          fontSize={16}
          name={nameState}
        />
      )
    })
  }

  const getAntsCircle = () => {

    return Object.keys(metaAnts).map(nameState => {
      return (
        <Circle
          // zIndex={0}
          key={te + nameState + '_circle'}
          {...metaAnts[nameState]}
          radius={10}
          fill={brown[100]}
          shadowBlur={6}
          shadowColor={brown[500]}
          name={nameState + '_circle'}
        />
      )
    })
  }

  const getAntsText = () => {
    return Object.keys(metaAnts).map(nameState => {
      return (
        <Text
          key={te + nameState + '_text'}
          {...metaAnts[nameState]}
          x={metaAnts[nameState].x - 5}
          y={metaAnts[nameState].y - 5}
          text={nameState}
          fill={'black'}
          fontSize={10}
          name={nameState + '_text'}
        />
      )
    })
  }

  return (
    <Stage
      width={props.width?.current?.offsetWidth}
      height={props.width?.current?.offsetHeight}
    >
      <Layer ref={layRef}>
        {getLinks()}

        {Object.keys(state).map(nameState => {
          return (
            <Circle
              {...state[nameState]}
              radius={30}
              fill={typeColor[String(state[nameState].type)][1]}
              shadowBlur={10}
              shadowColor={typeColor[String(state[nameState].type)][0]}
              name={nameState}
              draggable
              onDragMove={handleDrag}
            />
          )
        })}
        {getTextNode()}
        {getAntsCircle()}
        {getAntsText()}
      </Layer>
    </Stage>
  )
}

export default GraphLemin
